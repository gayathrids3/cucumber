/*package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	public ChromeDriver driver;
	@Given("Open The Browser")
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		 driver = new ChromeDriver();
	}
	@And("Max the Browser")
	public void maxBrowser() {
		driver.manage().window().maximize();
	}
	
	@And("Set the TimeOut")
	public void setTimeOut1() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@And("Launch The URL")
	public void launchTheURL() {
	    driver.get("http://leaftaps.com/opentaps");	    
	}

	@And("Enter the UserName as (.*)")
	public void enterTheUserName(String data) {
	   driver.findElementById("username").sendKeys(data);	    
	}

	@And("Enter the Password as (.*)")
	public void enterThePassword(String data) {
		 driver.findElementById("password").sendKeys(data);	    
	}

	@When("Click on the Login Button")
	public void clickOnTheLoginButton() {
		 driver.findElementByClassName("decorativeSubmit").click();	    
	}

	@Then("Verify the Login")
	public void verifyTheLogin() {
	   System.out.println("Success");	    
	}
	
	
	
	
	
	
	
	
}
*/